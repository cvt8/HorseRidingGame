/**
 * Concours de saut d'obstacle
 */
/**
 * @author constantin
 *
 */
package cso;